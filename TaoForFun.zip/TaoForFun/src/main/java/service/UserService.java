package service;

public interface UserService {

}
