package service.impl;

public class WeiboServiceImpl {

}
