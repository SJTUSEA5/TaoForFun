package service;

public interface WeiboService {

}
