package action;

public class LoginAction {

}
