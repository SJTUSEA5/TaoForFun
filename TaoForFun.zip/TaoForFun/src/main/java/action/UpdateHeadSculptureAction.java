package action;

public class UpdateHeadSculptureAction {

}
