package action;

public class UpdateUserAction {

}
