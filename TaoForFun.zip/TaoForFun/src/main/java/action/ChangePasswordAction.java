package action;

public class ChangePasswordAction {

}
