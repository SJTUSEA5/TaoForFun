package action;

public class DeleteUserAction {

}
