package action;

public class DeleteWeiboAction {

}
