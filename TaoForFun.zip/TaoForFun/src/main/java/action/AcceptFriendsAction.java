package action;

public class AcceptFriendsAction {

}
