package action;

public class SearchUserAction {

}
