package action;

public class UpdateBasicInfoAction {

}
