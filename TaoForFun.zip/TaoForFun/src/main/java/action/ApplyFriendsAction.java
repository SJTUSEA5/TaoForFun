package action;

public class ApplyFriendsAction {

}
