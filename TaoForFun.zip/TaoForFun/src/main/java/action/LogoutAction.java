package action;

public class LogoutAction {

}
