package action;

public class ShowWeiboAction {

}
