package action;

public class DeletePersonalWeiboAction {

}
