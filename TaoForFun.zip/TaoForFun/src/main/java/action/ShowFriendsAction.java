package action;

public class ShowFriendsAction {

}
