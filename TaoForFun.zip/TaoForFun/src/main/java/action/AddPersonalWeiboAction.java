package action;

public class AddPersonalWeiboAction {

}
