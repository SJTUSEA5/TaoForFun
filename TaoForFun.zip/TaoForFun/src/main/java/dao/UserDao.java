package dao;

public interface UserDao {

}
