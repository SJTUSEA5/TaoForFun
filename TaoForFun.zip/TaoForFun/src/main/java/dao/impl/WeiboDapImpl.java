package dao.impl;

public class WeiboDapImpl {

}
