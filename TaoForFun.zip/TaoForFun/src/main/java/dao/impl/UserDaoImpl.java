package dao.impl;

public class UserDaoImpl {

}
