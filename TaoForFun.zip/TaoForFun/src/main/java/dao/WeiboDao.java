package dao;

public interface WeiboDao {

}
